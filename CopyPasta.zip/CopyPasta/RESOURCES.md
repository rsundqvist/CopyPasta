# Resources

In no particular order.

## [Gson](https://github.com/google/gson)
Import/export of feedback and pasta.

## [RichTextFX](https://github.com/TomasMikula/RichTextFX)
Rendering of source code and feedback text with syntax highlighting.

## [Mastering Regular Expressions 3d edition](https://www-dawsonera-com.proxy.lib.chalmers.se/abstract/9780596550028)
Manage feedback tags.

## [7-Zip-JBinding](http://sevenzipjbind.sourceforge.net/)
TODO