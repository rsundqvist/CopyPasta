# Copy Pasta: Version History
___
#### Current Version: `PRERELEASE Rev2.1`
## Patch Notes
### `PRERELEASE Rev2.1`
28-02-2018
* Force UTF-8 encoding for import/export of .json-files
### `PRERELEASE Rev2`
28-02-2017
* Numerous bug fixes and quality-of-life improvements
* Added precompiled zip-folder with examples ("CopyPasta.zip")
### `PRERELEASE Rev1`
24-02-2017
* Pasta list always sorted
* Added Pasta tag type "assignment"
* Added Pasta keyowrd search (content, title, and tags)
### `PRERELEASE Rev0`
23-02-2017
> Initial version
