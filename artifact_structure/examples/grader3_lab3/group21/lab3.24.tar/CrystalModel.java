// Importing classes

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.GraphicsEnvironment;
import java.util.Scanner;
import java.awt.Robot;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;

/**
 * A model for simulating ion crystallization
 * 
 * @author Blom, Max
 * @author Klyver, Markus
 *
 * GROUP: 21
 */
public class CrystalModel {

	// Variables

	private int size;

	private boolean[][] stateMatrix;

	private int x;
	private int y;

	private int d;

	private int startRadius;
	private int escapeCircleRadius;

	/**
	 * @param size
	 *            The size of the window
	 */
	public CrystalModel(int size) {
		this.size = size;
		this.d = (int) (size / 2.0);
		this.startRadius = (int) (2.0 / 3.0 * ((double) d));
		this.escapeCircleRadius = (int) (8.0 / 9.0 * ((double) d));
		this.stateMatrix = new boolean[size][size];
	}

	/**
	 * JFrame for slider
	 */
	public static class CrystalView {
		private JFrame frame = new JFrame("Crystal Viewer");
		private JPanel panel;

		private BufferedImage image;

		private CrystalModel model;

		private ActionListener a;

		// Buttons
		private JButton changeSpeed = new JButton("Change Speed");
		private JButton start = new JButton("Start");
		private JButton stop = new JButton("Stop");

		private boolean paused = true;

		private int speed = 10;

		// Our JFrame and slider for changing simulation speed
		private JFrame window;
		private JSlider js;

		private void changeSpeed() {
			if (window == null || (window != null && !window.isVisible()))
				window = new ChangeSpeed();
			else if (window != null) {
				window.requestFocus();
				window.toFront();
			}
		}

		/**
		 * Changes the simulation speed
		 */
		private class ChangeSpeed extends JFrame {
			public ChangeSpeed() {
				this.setTitle("Change simulation speed");
				this.setSize(300, 100);
				this.setResizable(false);
				this.setLayout(new BorderLayout());

				js = new JSlider(1, 1000);

				js.setValue(speed);

				// Makes the slider nicer to look at
				js.setMinorTickSpacing(5);
				js.setPaintTicks(true);
				js.setPaintLabels(true);

				this.add(js, BorderLayout.NORTH);

				// Buttons
				JButton b1 = new JButton("Apply");
				JButton b2 = new JButton("Cancel");

				// Listeners
				b1.addActionListener(a);
				b2.addActionListener(a);

				this.add(b1, BorderLayout.WEST);
				this.add(b2, BorderLayout.EAST);

				this.pack();
				this.setVisible(true);
			}
		}

		/**
		 * JFrame for our main window
		 * 
		 * @param _model
		 *            A Crystalmodel instance
		 */
		public CrystalView(CrystalModel _model) {
			// JFrame
			frame = new JFrame("Crystallization simulator");
			frame.setTitle("Crystallization simulator");
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setSize(_model.size, _model.size + 100);
			frame.setResizable(false);
			panel = new View();

			panel.setSize(_model.size, _model.size);
			panel.setPreferredSize(new Dimension(_model.size, _model.size));

			frame.setLayout(new BorderLayout());

			frame.add(panel, BorderLayout.NORTH);
			frame.add(changeSpeed, BorderLayout.WEST);
			frame.add(start, BorderLayout.CENTER);
			frame.add(stop, BorderLayout.EAST);

			// Our listener
			a = new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.out.println(e.getActionCommand());

					switch (e.getActionCommand()) {
					case "Start":
						Start();

						start.setText("Pause");

						paused = !paused;
						break;
					case "Pause":
						start.setText("Start");

						paused = !paused;
						break;
					case "Stop":
						int size = model.size;

						model.stateMatrix = new boolean[size][size];
						model.stateMatrix[model.d][model.d] = true;

						image = new BufferedImage(size, size, BufferedImage.TYPE_INT_RGB);

						paused = true;

						start.setText("Start");
						break;
					case "Change Speed":
						changeSpeed();
						break;
					case "Apply":
						speed = js.getValue();
						window.dispose();
						window.setVisible(false);
						break;
					case "Cancel":
						window.dispose();
						window.setVisible(false);
						break;
					}
				}
			};

			changeSpeed.addActionListener(a);
			start.addActionListener(a);
			stop.addActionListener(a);

			frame.pack();

			frame.setVisible(true);

			this.model = _model;

			model.stateMatrix[model.d][model.d] = true;

			image = new BufferedImage(model.size, model.size, BufferedImage.TYPE_INT_RGB);
		}

		/**
		 * Generates the image
		 */
		private void GenerateImage() {
			boolean[][] modelMatrix = model.getModelMatrix();

			for (int x = 0; x < model.size; x++) {
				for (int y = 0; y < model.size; y++) {
					if (modelMatrix[x][y])
						image.setRGB(x, y, Color.GREEN.getRGB());
					else
						image.setRGB(x, y, Color.BLACK.getRGB());
				}
			}
		}

		private Thread t;

		private int iterations = 0;

		/**
		 * Starts the simulation
		 */
		public void Start() {
			t = new Thread() {
				public void run() {
					while (model.simulating) {
						if (!paused) {
							if (!model.crystallizeOneIon()) {
								paused = true;
							}
						}

						iterations++;

						if (iterations >= speed) {
							iterations = 0;

							GenerateImage();

							panel.repaint();
							frame.repaint();
						}
					}
				}
			};

			t.start();
		}

		/**
		 * Draws the generated image
		 */
		private class View extends JPanel {
			private static final long serialVersionUID = 1L;

			public void paint(Graphics g) {
				g.drawImage(image, 0, 0, panel.getWidth(), panel.getHeight(), this);
			}
		}
	}

	/**
	 * Returns the circle radius. If an ion is outside the radius, it will be
	 * dropped again inside the circle
	 * 
	 * @return The circle radius
	 */
	public int getEscapeCircleRadius() {
		return escapeCircleRadius;
	}

	public boolean getModelValue(int _x, int _y) {
		return stateMatrix[_x + d][_y + d];
	}

	public boolean[][] getModelMatrix() {
		return stateMatrix;
	}

	/**
	 * Saves the image when the simulation is done in the current folder using
	 * File.createTempFile();
	 */
	public void saveImage() {
		try {
			File f = null;
			// A new file in the current folder
			f = File.createTempFile("Crystal", ".png", new File("."));

			if (f.exists() && !f.isDirectory()) {
				f.createNewFile();
			}
			ImageIO.write(s.image, "bmp", f); // Writes output
			URI path = new URI(f.getAbsolutePath());

			// Prints the full path out, normalized
			System.out.println("Output written to\n" + path.normalize());
		} catch (IOException | URISyntaxException e) {
			// URISyntaxException must be caught, but will never
			// happen
			System.exit(1); // Error
		}

	}

	private boolean simulating = true;
	private int iteration = 0;

	/**
	 * Checks whether an ion will crystallize or not, based upon certain rules
	 * 
	 * @return true if the ion will crystallize, otherwise false
	 */
	public boolean crystallizeOneIon() {
		while (simulating) {
			int direction = (int) (Math.random() * 4);

			switch (direction) {
			case 0:
				x += 1;
				break;
			case 1:
				y += 1;
				break;
			case 2:
				x -= 1;
				break;
			case 3:
				y -= 1;
				break;
			}

			boolean willCrystallize = false; // Default

			// Checks whether it will crystallize or not
			for (int _x = -1 + x; _x <= 1 + x; _x++) {
				for (int _y = -1 + y; _y <= 1 + y; _y++) {
					if (_x >= 0 && _x < size && _y >= 0 && _y < size && stateMatrix[_x][_y])
						willCrystallize = true;
				}
			}

			if (Math.sqrt(s(x - d) + s(y - d)) > escapeCircleRadius) {
				createNewIon();
			}

			if (willCrystallize) {
				if (Math.sqrt(s(x - d) + s(y - d)) >= startRadius) {
					saveImage();
					// s.stop.doClick();
					return false;
				}

				stateMatrix[x][y] = true;
				createNewIon();

				return true;
			}
		}
		return false;
	}

	/**
	 * Doubles a number
	 * 
	 * @param b
	 *            A real number as a double
	 * @return Its square number
	 */
	public static double s(double b) {
		return b * b;
	}

	/**
	 * Calculates the Euclidean distance between two points from its coordinates
	 * measured in an orthonormal base
	 * 
	 * @param a
	 *            The coordinates of point a
	 * @param b
	 *            The coordinates of point b
	 * @throws Exception
	 *             If the vectors does not belong to the same vector space
	 * @return The Euclidean distance between the two points
	 */
	public static double dist(double[] a, double[] b) throws Exception {
		double sum = 0;

		if (a.length != b.length)
			throw new Exception("What the hell!?");
		else {
			for (int i = 0; i < a.length; i++) {
				sum += s(b[i] - a[i]);
			}
		}

		return Math.sqrt(sum);
	}

	/**
	 * Creates a new ion
	 */
	private void createNewIon() {
		double theta = Math.random() * 2 * Math.PI;

		x = (int) (Math.cos(theta) * startRadius) + d;
		y = (int) (Math.sin(theta) * startRadius) + d;
	}

	/**
	 * Our toString()-method
	 */
	public String toString() {
		int s1 = getEscapeCircleRadius();

		StringBuffer s = new StringBuffer(10000);

		for (int i = -s1 - 1; i < s1 + 1; i++) {
			s.append("-");
		}

		s.append("\n");

		for (int i = -s1; i < s1; i++) {
			s.append("|");
			for (int j = -s1; j < s1; j++) {
				if (getModelValue(i, j)) {
					if (i == x && j == y) {
						s.append("#");
					} else {
						s.append("*");
					}
				} else {
					s.append(" ");
				}
			}
			s.append("|");
			s.append("\n");
		}

		for (int i = -s1 - 1; i < s1 + 1; i++) {
			s.append("-");
		}

		s.append("\n");

		return s.toString();
	}

	public static CrystalView s;

	/**
	 * Our main program. Does parsing of arguments and exception catching
	 * 
	 * @param args
	 *            Arguments from terminal
	 */
	public static void main(String[] args) {

		int argsize = 0;
		double scalefactor = 0.8; // Scaling factor

		// Would let the user to specify file path to save the image

		// Making sure the user doesn't mess things up.
		if (args.length != 1) {
			System.out.println ("Usage: java CrystalModel [crystal bath size]. The size must be larger that 100, but smaller than min(screenWidth, screenHeight); resizing will occur otherwise.");
			System.exit(1);
		}

		// Making sure the user doesn't mess things up.
		try {
			argsize = Integer.parseInt(args[0]);
		} catch (Exception e) {
			System.exit(1); // Error
		}

		// If the height or width are too high, set the window to
		// scale * max(height, width)
		int height = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds().height;
		int width = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds().width;

		// Making sure the user doesn't mess things up.
		if (argsize < 200) {
			System.out.println ("Forbidden size; rescaling to 200.");

			argsize = 200;
		}

		// Making sure the user doesn't mess things up.
		if (width > height && (argsize > height || argsize > width)) {
			argsize = (int) (scalefactor * height);

			System.out.println ("Forbidden size; rescaling to " + scalefactor * height + ".");
		} else if (argsize > height || argsize > width) {
			argsize = (int) (scalefactor * width);

			System.out.println ("Forbidden size; rescaling to " + scalefactor * width + ".");
		}

		s = new CrystalView(new CrystalModel(argsize));
	}
}
