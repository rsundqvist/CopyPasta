import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
* Purpose: Creating a control panel with buttons and crystal view panel. <p>
* Author: Albin Baeckstrand <p>
* Group: 67 <p>
* Assignment: Laboration 3 steg 3, kristallbildning <p>
* Last changed: 2017-01-30
*/
public class CrystalControl extends JPanel{
	
	private CrystalModel cm; // crystal model
	private CrystalView crystalPanel; // crystal view panel
	private Timer timer; // timer for the simulation
	private int speed; // regulates the "speed" of simulation (step size)
	
	/**
	* Creating a control panel with buttons and a crystal view panel.
	* @param size is width and height of crystal view panel.
	*/
	public CrystalControl(int size) {
		
		this.cm = new CrystalModel(size);
		cm.reset(); // reset before painting default crystal panel
		
		this.crystalPanel = new CrystalView(cm);
		crystalPanel.setPreferredSize(new Dimension(size,size)); // set size*size
		
		this.timer = new Timer(50, new TimerListener()); // delay is 50 ms
		
		this.speed = 20; // default speed (step size)
		
		// button options
		JButton changeSpeedButton = new JButton("Change Speed");
		changeSpeedButton.addActionListener(new SpeedButtonListener());
		
		JButton runButton = new JButton("Run");
		runButton.addActionListener(new RunButtonListener());
		
		JButton stopButton = new JButton("Stop");
		stopButton.addActionListener(new StopButtonListener());
		
		// control panel options
		setLayout(new BorderLayout());
		add(crystalPanel,BorderLayout.NORTH);
		add(changeSpeedButton,BorderLayout.WEST);
		add(runButton,BorderLayout.CENTER);
		add(stopButton,BorderLayout.EAST);
		
	}
	
	/**
	* ActionListener for the timer.
	*/
	private class TimerListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			// add speed crystallized ions for every delay time
			// stop timer if simulation is complete
			if(!cm.runSomeSteps(speed)) {
				timer.stop();
			}
			crystalPanel.repaint(); // repaint crystal panel
		}
	}
	
	/**
	* ActionListener for "change speed" button.
	*/
	private class SpeedButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			// Option pane
			String input = JOptionPane.showInputDialog("Please enter simulation speed: ");
			speed = Integer.parseInt(input);
		}
	}
	
	/**
	* ActionListener for "run" button.
	*/
	private class RunButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			cm.reset(); // reset current crystal model
			timer.start(); // start timer
		}
	}
	
	/**
	* ActionListener for "stop" button.
	*/
	private class StopButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			timer.stop(); // stop timer
		}
	}
}
