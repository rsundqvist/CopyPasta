/**
* Purpose: Simulate crystallization of zinc ions in an electrolyte bath  <p>
* Author: Albin Baeckstrand <p>
* Group: 67 <p>
* Assignment: Laboration 3 steg 3, kristallbildning  <p>
* Last changed: 2017-01-30
* Notifications: runSomeSteps() method is added and toString() is deleted. Some simple  <p>
* modifications in getModelValue is made and some methods are changed to public.
*/
public class CrystalModel {

	private int size; // the pixel size of square shaped electrolyte (size*size pixels)
	private boolean [][] m; // electrolyte crystal matrix
	private int escapeRadius; // radius of escape circle
	private int startRadius; // radius of start circle
	private int x; // x coordinate of ion
	private int y; // y coordinate of ion

	/**
	* Constructor that creates a crystal model.
	* @param size is the number of pixels at one side of the square shaped electrolyte bath.
	*/
	CrystalModel(int size) {
		this.size = size;
		this.escapeRadius = size/2-4;
		this.startRadius = (int) (escapeRadius*0.90);
	}
	
	/**
	* @return the x coordinate of an ion.
	*/
	public int getX() {
		return x;
	}
	
	/**
	* @return the y coordinate of an ion.
	*/
	public int getY() {
		return y;
	}
	
	/**
	* Change from local x coordinate (origin in the middle) to <p>
	* model x coordinate (origin in the upper left corner).
	* @param x is the local x coordinate.
	* @return the model x coordinate.
	*/
	public int xBathToModelRep(int x) {
		return size/2+x;
	}
	
	/**
	* Change from local y coordinate (origin in the middle) to <p>
	* model y coordinate (origin in the upper left corner).
	* @param y is the local y coordinate.
	* @return the model y coordinate.
	*/
	public int yBathToModelRep(int y) {
		return size/2+y;
	}
	
	/**
	* Creates an empty electrolyte bath with one crystallized ion in the middle.
	*/
	public void reset() {
		m = new boolean[size][size]; // All values defaults to false
		m[xBathToModelRep(0)][yBathToModelRep(0)] = true; // Crystal ion in the origin
	}
	
	/**
	* Determines if (x,y) is outside a circle with radius r.
	* @param r is the radius of a circle.
	* @param x is a local x coordinate.
	* @param y is a local y coordinate.
	* @return true if the point (x,y) is located outside the circle.
	*/
	private boolean outsideCircle(int r, int x, int y) {
		return x*x+y*y > r*r; // pythagorean theorem
	}
	
	/**
	* Determines if an ion with position (x,y) is next to a crystallized ion <p>
	* (up, down, left or right).
	* @param x is a local x coordinate of the ion.
	* @param y is a local y coordinate of the ion.
	* @return true if the ion is next to a crystallized ion.
	*/
	private boolean anyNeighbours(int x, int y) {
		int X = xBathToModelRep(x);
		int Y = yBathToModelRep(y); 
		return m[X-1][Y] || m[X+1][Y] || m[X][Y-1] || m[X][Y+1];
	}
	
	/**
	* Determine if its a crystallized ion in point (x,y).
	* @param x is a model x coordinate.
	* @param y is a model y coordinate.
	* @return true if its a crystallized ion in point (x,y)
	*/
	public boolean getModelValue(int x, int y) {
		return m[x][y];
	}
	
	/**
	* Drops an ion somewhere on the "start circle" (randomly).
	*/
	private void dropNewIon() {
		double theta = Math.random()*2*Math.PI; // 0 <= theta < 2*pi
		if((startRadius*Math.cos(theta))%1 >= 0.5) {
			x = (int) (startRadius*Math.cos(theta)+1);
		} else {
			x = (int) (startRadius*Math.cos(theta));
		}
		if((startRadius*Math.sin(theta))%1 >= 0.5) {
			y = (int) (startRadius*Math.sin(theta)+1);
		} else {
			y = (int) (startRadius*Math.sin(theta));
		}
	}
	
	/**
	* Crystallize an ion next to an already crystallized ion. The ion moves randomly up, down, <p>
	* left or right with the starting point somewhere on the "start circle". If the ion moves outside <p>
	* the "escape circle" another ion is released from the "start circle".
	* @return false if the ion crystallizes on the "start circle" otherwise true.
	*/
	public boolean crystallizeOneIon() {
		dropNewIon();
		int randNum; // 0, 1, 2 or 3
		do {
			if(outsideCircle(escapeRadius,x,y)) {
				dropNewIon();
			}
			randNum = (int) (Math.random()*4);
			if(randNum == 0) {
				x = getX()-1; // left
			} else if(randNum == 1) {
				y = getY()+1; // up
			} else if(randNum == 2) {
				x = getX()+1; // right
			} else {
				y = getY()-1; // down
			}
			
		} while(!anyNeighbours(x,y));
		
		m[xBathToModelRep(x)][yBathToModelRep(y)] = true;
		return !outsideCircle(startRadius,x,y);
	}
	
	/**
	* Add at most steps crystallized ions to the crystal.
	* @param steps is the number of crystallized ions added.
	* @return true if crystallizeOneIon() is true, i.e. when the last <p>
	* ion is crystallized on the "start circle".
	*/
	public boolean runSomeSteps(int steps) {
		int i = 0;
		boolean goOn = false;
		do {
			goOn = crystallizeOneIon();
			i++;
		} while (i < steps && goOn);
		return goOn;
	}
}