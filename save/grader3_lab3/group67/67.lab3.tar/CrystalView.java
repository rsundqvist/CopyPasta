import javax.swing.*;
import java.awt.*;
/**
* Purpose: Creating a crystal view panel of a CrystalModel object. <p>
* Author: Albin Baeckstrand <p>
* Group: 67 <p>
* Assignment: Laboration 3 steg 3, kristallbildning <p>
* Last changed: 2017-01-30
*/
public class CrystalView extends JPanel {
	
	private CrystalModel cm;
	
	/**
	* Creating a crystal view panel of CrystalModel cm.
	* @param cm is the CrystalModel object
	*/
	public CrystalView(CrystalModel cm) {
		setBackground(Color.BLACK);
		this.cm = cm;
	}
	
	/**
	* Paint component of CrystalView.
	*/
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		// all crystallized ions are painted as red dots
		g.setColor(Color.RED);
		for(int x = 0; x < getWidth(); x++) {
			for(int y = 0; y < getHeight(); y++) {
				if(cm.getModelValue(x,y)) {
					g.drawLine(x,y,x,y);
				}
			}
		}
		// last crystallized ion is painted as a green dot
		g.setColor(Color.GREEN);
		int X = cm.xBathToModelRep(cm.getX());
		int Y = cm.xBathToModelRep(cm.getY());
		g.drawLine(X,Y,X,Y);
	}
}