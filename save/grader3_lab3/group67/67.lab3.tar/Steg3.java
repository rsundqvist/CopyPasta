import javax.swing.*;
import java.util.*;
/**
* Purpose: Main class to CrystalModel steg 3 <p>
* Author: Albin Baeckstrand <p>
* Group: 67 <p>
* Assignment: Laboration 3 steg 3, kristallbildning <p>
* Last changed: 2017-01-30
*/
public class Steg3 extends JFrame {
	/**
	* Creating a frame that holds control panel
	* @param size is width and height of crystal view panel in control panel
	*/
	public Steg3(int size) {
		// some frame properties
		setTitle("Crystal Experiment");
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		// add the control panel
		CrystalControl controlPanel = new CrystalControl(size);
		add(controlPanel);
		// pack and make visible
		pack();
		setVisible(true);
	}
	
	/**
	* @param args is an argument that represent the size of crystal view panel. <p>
	* Note that args.length == 1 and 100 <= args[0] <= 1000.
	*/
	public static void main(String[] args) {
		if(args.length == 1) { // only one argument
			try { // catch argument exception
				int size = Integer.parseInt(args[0]); // invert from string to int
				if(100 <= size && size <= 1000) { // within 100 <= size <= 1000
					new Steg3(size);
				} else {
					System.out.println("Argument must be within interval from 100 to 1000");
				}
			} catch(IllegalArgumentException e) {
				System.out.println("Argument must be of type Int"); // or a string that can be inverted to
			}														// a int.
		} else {
			System.out.println("Too few or too many arguments");
		}
	}
}
